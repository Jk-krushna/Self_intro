export const PROFILE = {
  name: 'KRUSHNA JADHAV',
  avatarUrl: 'https://res.cloudinary.com/e5ohcxz4/image/upload/f_auto,q_auto/profile',
  subtitle: 'ELECTRONICS & COMPUTER ENGINEERING | EMBEDDED SYSTEMS & DEFENSE TECH',
  badges: [
    { label: '2x NDA Written Qualified', tone: 'green' },
    { label: 'Hardware-Software Co-Design & Edge AI', tone: 'cyan' },
    { label: 'Tactical Electronics & Embedded Systems', tone: 'red' },
  ],
  social: [
    { label: 'GitHub', kind: 'github', href: '#' },
    { label: 'LinkedIn', kind: 'linkedin', href: '#' },
    { label: 'Email', kind: 'mail', href: '#' },
  ],
} as const;

export const DEFENSE_FOCUS = [
  'Ballistic electronics & fire-control telemetry',
  'Optical target acquisition systems',
  'AK-47 gas-operation dynamics',
  'M4A1 modular platform engineering',
  'Precision sniper rifle ballistics',
] as const;

export const ACADEMIC_GROUPS = [
  { title: 'Microcontrollers', items: ['8051 MCU', 'ESP32'] },
  { title: 'Software & Systems', items: ['Operating Systems', 'DBMS', 'OOP (Java) & DSA'] },
  { title: 'Core Electronics', items: ['Network Theory', 'Analog & Digital Electronics', 'DSIP'] },
] as const;

export const TARGET_ORGS = [
  {
    id: 'nvidia',
    name: 'NVIDIA',
    focus: 'Embedded AI & Hardware Acceleration',
    metrics: ['Edge inference throughput', 'Accelerator datapath design', 'Power efficiency'],
  },
  {
    id: 'samsung',
    name: 'Samsung R&D',
    focus: 'VLSI Design',
    metrics: ['Logic verification', 'Timing closure', 'Physical layout quality'],
  },
] as const;

export type ArsenalCategory = 'hardware' | 'cad' | 'software';

export const ARSENAL: { id: string; name: string; category: ArsenalCategory }[] = [
  { id: '8051', name: '8051 MCU', category: 'hardware' },
  { id: 'esp32', name: 'ESP32', category: 'hardware' },
  { id: 'lcd', name: '16x2 LCD Interfacing', category: 'hardware' },
  { id: 'kicad', name: 'KiCad', category: 'cad' },
  { id: 'proteus', name: 'Proteus', category: 'cad' },
  { id: 'ltspice', name: 'LTspice', category: 'cad' },
  { id: 'java', name: 'Java (OOP/DSA)', category: 'software' },
  { id: 'python', name: 'Python', category: 'software' },
];

export const ARSENAL_TABS: { id: ArsenalCategory; label: string }[] = [
  { id: 'hardware', label: 'Hardware & MCU' },
  { id: 'cad', label: 'CAD & Simulation' },
  { id: 'software', label: 'CS & Software' },
];

export interface LabProject {
  id: string;
  title: string;
  tag: string;
  summary: string;
  flow: string[];
  parameters: { label: string; value: string }[];
}

export const LAB_PROJECTS: LabProject[] = [
  {
    id: 'tnetwork',
    title: 'Z/Y Two-Port Resistive T-Network PCB Layout Verification',
    tag: 'PCB & Network Theory',
    summary:
      'Laid out a resistive T-network on a PCB and checked the board against the calculated two-port Z- and Y-parameters.',
    flow: ['Analytical Z/Y model', 'PCB layout (KiCad)', 'Circuit simulation (LTspice)', 'Bench verification'],
    parameters: [
      { label: 'Topology', value: 'Resistive T-network' },
      { label: 'Parameter sets', value: 'Z (open-circuit), Y (short-circuit)' },
      { label: 'Verification', value: 'Layout vs. analytical two-port model' },
      { label: 'Tools', value: 'KiCad, LTspice' },
    ],
  },
  {
    id: '8051',
    title: '8051 Hardware Interfacing & Assembly',
    tag: 'Microcontrollers',
    summary: 'Interfaced a 16x2 LCD and peripherals with an 8051 microcontroller, writing the control routines in assembly.',
    flow: ['8051 MCU', '16x2 LCD (4-bit mode)', 'Assembly routines', 'Proteus simulation'],
    parameters: [
      { label: 'Microcontroller', value: '8051 family' },
      { label: 'Display', value: '16x2 character LCD' },
      { label: 'Language', value: '8051 Assembly' },
      { label: 'Simulator', value: 'Proteus' },
    ],
  },
  {
    id: 'dsp',
    title: 'Digital Oscilloscope Signal Processing',
    tag: 'DSIP',
    summary: 'Sampled and processed periodic waveforms to study sine and square signal behaviour in the time domain.',
    flow: ['Signal source', 'Sampling (ADC)', 'DSP filtering (DSIP)', 'Waveform display'],
    parameters: [
      { label: 'Domain', value: 'Digital signal & image processing' },
      { label: 'Waveforms', value: 'Sine, square' },
      { label: 'Display', value: 'Time-domain trace' },
      { label: 'Tools', value: 'Java, Python' },
    ],
  },
];
