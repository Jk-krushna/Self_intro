import { useEffect, useRef } from 'react';
import { useAnimationCanvas, type DrawFn } from '@/hooks/useAnimationCanvas';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
}

interface PointerState {
  x: number;
  y: number;
  smoothX: number;
  smoothY: number;
  visible: boolean;
  pressed: number;
}

export default function CursorReticle() {
  const pointer = useRef<PointerState>({ x: 0, y: 0, smoothX: 0, smoothY: 0, visible: false, pressed: 0 });
  const particles = useRef<Particle[]>([]);

  const draw: DrawFn = (ctx, _width, _height, time) => {
    const p = pointer.current;
    const list = particles.current;
    if (!p.visible) return;

    p.smoothX += (p.x - p.smoothX) * 0.25;
    p.smoothY += (p.y - p.smoothY) * 0.25;
    const speed = Math.hypot(p.x - p.smoothX, p.y - p.smoothY);
    if (speed > 0.5 && list.length < 80) {
      list.push({ x: p.smoothX, y: p.smoothY, vx: (Math.random() - 0.5) * 0.4, vy: (Math.random() - 0.5) * 0.4, life: 1 });
    }

    for (let i = list.length - 1; i >= 0; i--) {
      const particle = list[i];
      particle.x += particle.vx;
      particle.y += particle.vy;
      particle.life -= 0.035;
      if (particle.life <= 0) {
        list.splice(i, 1);
        continue;
      }
      ctx.fillStyle = `rgba(0, 242, 254, ${particle.life * 0.7})`;
      ctx.fillRect(particle.x - 1.5, particle.y - 1.5, 3, 3);
    }

    const { smoothX: x, smoothY: y } = p;
    const pressScale = p.pressed > 0 ? 0.8 : 1;
    const spin = time * 1.6;
    const r = 22 * pressScale;

    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(spin);
    ctx.strokeStyle = '#00f2fe';
    ctx.lineWidth = 1.5;
    ctx.shadowColor = 'rgba(0, 242, 254, 0.8)';
    ctx.shadowBlur = 10;
    for (let i = 0; i < 4; i++) {
      ctx.beginPath();
      ctx.arc(0, 0, r, i * (Math.PI / 2) + 0.15, i * (Math.PI / 2) + Math.PI / 2 - 0.15);
      ctx.stroke();
    }
    ctx.restore();

    ctx.save();
    ctx.translate(x, y);
    ctx.strokeStyle = 'rgba(0, 242, 254, 0.7)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(-r - 8, 0);
    ctx.lineTo(-r + 4, 0);
    ctx.moveTo(r - 4, 0);
    ctx.lineTo(r + 8, 0);
    ctx.moveTo(0, -r - 8);
    ctx.lineTo(0, -r + 4);
    ctx.moveTo(0, r - 4);
    ctx.lineTo(0, r + 8);
    ctx.stroke();
    ctx.fillStyle = p.pressed > 0 ? '#ff0055' : '#00f2fe';
    ctx.shadowColor = p.pressed > 0 ? '#ff0055' : '#00f2fe';
    ctx.shadowBlur = 12;
    ctx.beginPath();
    ctx.arc(0, 0, 2.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    if (p.pressed > 0) p.pressed -= 0.08;
  };

  const canvasRef = useAnimationCanvas(draw);

  useEffect(() => {
    const fine = window.matchMedia('(pointer: fine)').matches;
    if (!fine) return;

    document.documentElement.classList.add('hud-cursor');
    const onMove = (event: PointerEvent) => {
      pointer.current.x = event.clientX;
      pointer.current.y = event.clientY;
      if (!pointer.current.visible) {
        pointer.current.smoothX = event.clientX;
        pointer.current.smoothY = event.clientY;
      }
      pointer.current.visible = true;
    };
    const onLeave = () => {
      pointer.current.visible = false;
    };
    const onDown = (event: PointerEvent) => {
      pointer.current.pressed = 1;
      for (let i = 0; i < 14; i++) {
        const angle = (Math.PI * 2 * i) / 14;
        particles.current.push({
          x: event.clientX,
          y: event.clientY,
          vx: Math.cos(angle) * (1.2 + Math.random()),
          vy: Math.sin(angle) * (1.2 + Math.random()),
          life: 1,
        });
      }
    };

    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerdown', onDown);
    document.addEventListener('pointerleave', onLeave);
    return () => {
      document.documentElement.classList.remove('hud-cursor');
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerdown', onDown);
      document.removeEventListener('pointerleave', onLeave);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 z-[100] h-full w-full"
    />
  );
}
