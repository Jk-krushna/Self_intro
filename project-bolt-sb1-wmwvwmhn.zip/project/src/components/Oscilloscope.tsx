import { useAnimationCanvas, type DrawFn } from '@/hooks/useAnimationCanvas';

const TAU = Math.PI * 2;

function drawScope(ctx: CanvasRenderingContext2D, width: number, height: number) {
  ctx.strokeStyle = 'rgba(0, 242, 254, 0.12)';
  ctx.lineWidth = 1;
  for (let i = 1; i < 8; i++) {
    const x = (width / 8) * i;
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, height);
    ctx.stroke();
  }
  for (let i = 1; i < 4; i++) {
    const y = (height / 4) * i;
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(width, y);
    ctx.stroke();
  }
  ctx.strokeStyle = 'rgba(0, 242, 254, 0.3)';
  ctx.beginPath();
  ctx.moveTo(0, height / 2);
  ctx.lineTo(width, height / 2);
  ctx.stroke();
}

function wave(ctx: CanvasRenderingContext2D, width: number, height: number, shape: (phase: number) => number, phase: number, amp: number, color: string) {
  ctx.strokeStyle = color;
  ctx.shadowColor = color;
  ctx.shadowBlur = 8;
  ctx.lineWidth = 1.8;
  ctx.beginPath();
  for (let x = 0; x <= width; x += 2) {
    const t = (x / width) * 2;
    const y = height / 2 - shape(t * TAU + phase) * amp * height;
    if (x === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.stroke();
  ctx.shadowBlur = 0;
}

const sine = (p: number) => Math.sin(p);
const square = (p: number) => (Math.sin(p) >= 0 ? 1 : -1);

const drawOscilloscope: DrawFn = (ctx, width, height, time) => {
  drawScope(ctx, width, height);
  wave(ctx, width, height, sine, -time * 4, 0.36, '#00f2fe');
  wave(ctx, width, height, square, -time * 2, 0.22, '#00ff87');

  ctx.fillStyle = '#00ff87';
  ctx.font = '600 10px "JetBrains Mono", monospace';
  ctx.textAlign = 'left';
  ctx.fillText('CH1 SINE', 8, 14);
  ctx.fillStyle = '#00f2fe';
  ctx.fillText('CH2 SQUARE', 8, 28);
};

export default function Oscilloscope() {
  const canvasRef = useAnimationCanvas(drawOscilloscope);
  return <canvas ref={canvasRef} aria-hidden="true" className="h-full w-full" />;
}
