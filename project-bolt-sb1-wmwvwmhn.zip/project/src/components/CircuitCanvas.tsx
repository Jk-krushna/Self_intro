import { useAnimationCanvas, type DrawFn } from '@/hooks/useAnimationCanvas';

interface Chip {
  x: number;
  y: number;
  w: number;
  h: number;
  label: string;
}

const CHIPS: Chip[] = [
  { x: 0.1, y: 0.22, w: 0.2, h: 0.26, label: '8051' },
  { x: 0.42, y: 0.12, w: 0.16, h: 0.18, label: 'ESP32' },
  { x: 0.64, y: 0.44, w: 0.2, h: 0.2, label: 'ADC' },
  { x: 0.12, y: 0.66, w: 0.16, h: 0.14, label: 'LCD' },
];

const TRACES: number[][][] = [
  [[0.3, 0.35], [0.36, 0.35], [0.36, 0.21], [0.42, 0.21]],
  [[0.58, 0.21], [0.7, 0.21], [0.7, 0.44]],
  [[0.3, 0.55], [0.5, 0.55], [0.5, 0.5], [0.64, 0.5]],
  [[0.22, 0.48], [0.22, 0.66]],
  [[0.84, 0.54], [0.92, 0.54], [0.92, 0.82], [0.7, 0.82], [0.7, 0.64]],
  [[0.5, 0.21], [0.5, 0.06], [0.9, 0.06], [0.9, 0.2]],
];

const SENSOR = { x: 0.9, y: 0.82, r: 0.05 };

function pointAlong(points: [number, number][], t: number, width: number, height: number) {
  const px = points.map(([x, y]) => [x * width, y * height] as const);
  const lengths: number[] = [];
  let total = 0;
  for (let i = 1; i < px.length; i++) {
    const seg = Math.hypot(px[i][0] - px[i - 1][0], px[i][1] - px[i - 1][1]);
    lengths.push(seg);
    total += seg;
  }
  let target = t * total;
  for (let i = 0; i < lengths.length; i++) {
    if (target <= lengths[i]) {
      const f = target / lengths[i];
      return [px[i][0] + (px[i + 1][0] - px[i][0]) * f, px[i][1] + (px[i + 1][1] - px[i][1]) * f];
    }
    target -= lengths[i];
  }
  return [px[px.length - 1][0], px[px.length - 1][1]];
}

const drawCircuit: DrawFn = (ctx, width, height, time) => {
  ctx.strokeStyle = 'rgba(0, 242, 254, 0.07)';
  ctx.lineWidth = 1;
  for (let x = 0; x < width; x += 24) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, height);
    ctx.stroke();
  }
  for (let y = 0; y < height; y += 24) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(width, y);
    ctx.stroke();
  }

  ctx.lineWidth = 1.5;
  TRACES.forEach((trace) => {
    const points = trace as [number, number][];
    ctx.strokeStyle = 'rgba(0, 242, 254, 0.35)';
    ctx.beginPath();
    points.forEach(([x, y], i) => {
      const px = x * width;
      const py = y * height;
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    });
    ctx.stroke();
  });

  TRACES.forEach((trace, i) => {
    const points = trace as [number, number][];
    const t = (time * 0.18 + i * 0.23) % 1;
    const [x, y] = pointAlong(points, t, width, height);
    ctx.fillStyle = '#00ff87';
    ctx.shadowColor = '#00ff87';
    ctx.shadowBlur = 10;
    ctx.beginPath();
    ctx.arc(x, y, 2.6, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
  });

  CHIPS.forEach((chip) => {
    const x = chip.x * width;
    const y = chip.y * height;
    const w = chip.w * width;
    const h = chip.h * height;
    ctx.fillStyle = 'rgba(0, 242, 254, 0.08)';
    ctx.strokeStyle = 'rgba(0, 242, 254, 0.8)';
    ctx.shadowColor = 'rgba(0, 242, 254, 0.6)';
    ctx.shadowBlur = 12;
    ctx.fillRect(x, y, w, h);
    ctx.strokeRect(x, y, w, h);
    ctx.shadowBlur = 0;
    ctx.fillStyle = '#00f2fe';
    ctx.font = '600 11px "JetBrains Mono", monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(chip.label, x + w / 2, y + h / 2);
  });

  const sx = SENSOR.x * width;
  const sy = SENSOR.y * height;
  const pulse = 1 + 0.15 * Math.sin(time * 4);
  ctx.strokeStyle = '#ff0055';
  ctx.shadowColor = '#ff0055';
  ctx.shadowBlur = 14;
  ctx.beginPath();
  ctx.arc(sx, sy, SENSOR.r * Math.min(width, height) * pulse, 0, Math.PI * 2);
  ctx.stroke();
  ctx.shadowBlur = 0;
  ctx.fillStyle = '#ff0055';
  ctx.font = '600 9px "JetBrains Mono", monospace';
  ctx.fillText('SENSOR', sx, sy + 26);

  const clock = (16 + Math.sin(time * 3) * 0.012).toFixed(3);
  ctx.textAlign = 'left';
  ctx.textBaseline = 'alphabetic';
  ctx.fillStyle = 'rgba(0, 242, 254, 0.9)';
  ctx.font = '600 11px "JetBrains Mono", monospace';
  ctx.fillText(`CLK ${clock} MHz`, 12, height - 12);
};

export default function CircuitCanvas() {
  const canvasRef = useAnimationCanvas(drawCircuit);
  return <canvas ref={canvasRef} aria-hidden="true" className="h-full w-full" />;
}
