import { ArrowUpRight } from 'lucide-react';
import { useCallback, useState } from 'react';
import BentoCard from '@/components/BentoCard';
import Oscilloscope from '@/components/Oscilloscope';
import ProjectModal from '@/components/ProjectModal';
import { LAB_PROJECTS, type LabProject } from '@/data/profile';

export default function LabCard({ className = '' }: { className?: string }) {
  const [selected, setSelected] = useState<LabProject | null>(null);
  const closeModal = useCallback(() => setSelected(null), []);

  return (
    <BentoCard code="LAB-06 // SIGNAL" title="Real-Time Lab Work & Signal Oscilloscope" tone="red" className={className}>
      <div className="relative h-36 overflow-hidden rounded-lg border border-hud-green/20 bg-stealth/80">
        <Oscilloscope />
      </div>

      <ul className="mt-4 flex flex-col gap-2">
        {LAB_PROJECTS.map((project) => (
          <li key={project.id}>
            <button
              type="button"
              onClick={() => setSelected(project)}
              className="group/lab flex w-full items-center justify-between gap-3 rounded-lg border border-white/10 bg-stealth/50 px-3.5 py-3 text-left transition-all duration-300 hover:border-hud-red/50 hover:bg-hud-red/5 hover:shadow-glow-red"
            >
              <span>
                <span className="block text-sm font-medium leading-snug text-slate-100">{project.title}</span>
                <span className="mt-0.5 block font-mono text-[10px] uppercase tracking-wider text-slate-500">{project.tag}</span>
              </span>
              <ArrowUpRight className="h-4 w-4 shrink-0 text-hud-red transition-transform duration-300 group-hover/lab:translate-x-0.5 group-hover/lab:-translate-y-0.5" />
            </button>
          </li>
        ))}
      </ul>

      <ProjectModal project={selected} onClose={closeModal} />
    </BentoCard>
  );
}
