import { AnimatePresence, motion } from 'framer-motion';
import { ArrowRight, X } from 'lucide-react';
import { useEffect } from 'react';
import type { LabProject } from '@/data/profile';

interface ProjectModalProps {
  project: LabProject | null;
  onClose: () => void;
}

export default function ProjectModal({ project, onClose }: ProjectModalProps) {
  useEffect(() => {
    if (!project) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [project, onClose]);

  return (
    <AnimatePresence>
      {project && (
        <motion.div
          key="backdrop"
          role="dialog"
          aria-modal="true"
          aria-labelledby="project-modal-title"
          className="fixed inset-0 z-[90] flex items-center justify-center bg-stealth/80 p-4 backdrop-blur-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
        >
          <motion.div
            key={project.id}
            initial={{ opacity: 0, y: 24, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 16, scale: 0.98 }}
            transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
            onClick={(event) => event.stopPropagation()}
            className="glass-panel hud-corners relative max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl p-6 shadow-glow-cyan md:p-8"
          >
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-hud-cyan/70">{project.tag}</p>
                <h3 id="project-modal-title" className="mt-2 font-display text-lg font-bold uppercase leading-tight text-white md:text-xl">
                  {project.title}
                </h3>
              </div>
              <button
                type="button"
                onClick={onClose}
                aria-label="Close project details"
                className="shrink-0 rounded-md border border-hud-cyan/30 p-2 text-hud-cyan transition-colors hover:bg-hud-cyan/10"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <p className="mt-4 text-sm leading-relaxed text-slate-300">{project.summary}</p>

            <p className="mt-6 font-mono text-[10px] uppercase tracking-[0.2em] text-slate-500">Signal flow</p>
            <ol className="mt-3 flex flex-wrap items-center gap-2">
              {project.flow.map((step, i) => (
                <li key={step} className="flex items-center gap-2">
                  <span className="rounded-md border border-hud-green/35 bg-hud-green/10 px-2.5 py-1.5 font-mono text-[11px] text-hud-green">
                    {step}
                  </span>
                  {i < project.flow.length - 1 && <ArrowRight className="h-3.5 w-3.5 text-hud-cyan/60" />}
                </li>
              ))}
            </ol>

            <p className="mt-6 font-mono text-[10px] uppercase tracking-[0.2em] text-slate-500">Technical parameters</p>
            <dl className="mt-3 grid gap-3 sm:grid-cols-2">
              {project.parameters.map((param) => (
                <div key={param.label} className="rounded-lg border border-hud-cyan/15 bg-stealth/70 px-3 py-2.5">
                  <dt className="font-mono text-[10px] uppercase tracking-wider text-slate-500">{param.label}</dt>
                  <dd className="mt-1 text-sm text-slate-200">{param.value}</dd>
                </div>
              ))}
            </dl>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
