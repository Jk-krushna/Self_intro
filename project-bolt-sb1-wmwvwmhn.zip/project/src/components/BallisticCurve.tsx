import { useAnimationCanvas, type DrawFn } from '@/hooks/useAnimationCanvas';

const MUZZLE_VELOCITY = 715;
const GRAVITY = 9.81;
const MAX_RANGE = 800;
const PAD = { left: 28, right: 12, top: 14, bottom: 22 };

const drawTrajectory: DrawFn = (ctx, width, height, time) => {
  const plotW = width - PAD.left - PAD.right;
  const plotH = height - PAD.top - PAD.bottom;
  const elevation = (0.6 + 0.3 * Math.sin(time * 0.5)) * (Math.PI / 180);

  const drop = (x: number) => x * Math.tan(elevation) - (GRAVITY * x * x) / (2 * MUZZLE_VELOCITY ** 2 * Math.cos(elevation) ** 2);
  let peak = 0;
  for (let x = 0; x <= MAX_RANGE; x += 10) peak = Math.max(peak, drop(x));
  const scaleY = (plotH * 0.7) / Math.max(peak, 0.001);
  const toPx = (x: number) => PAD.left + (x / MAX_RANGE) * plotW;
  const toPy = (y: number) => PAD.top + plotH - (y * scaleY) - plotH * 0.1;

  ctx.strokeStyle = 'rgba(0, 242, 254, 0.12)';
  ctx.lineWidth = 1;
  for (let x = 0; x <= MAX_RANGE; x += 200) {
    ctx.beginPath();
    ctx.moveTo(toPx(x), PAD.top);
    ctx.lineTo(toPx(x), PAD.top + plotH);
    ctx.stroke();
    ctx.fillStyle = 'rgba(148, 163, 184, 0.7)';
    ctx.font = '10px "JetBrains Mono", monospace';
    ctx.textAlign = 'center';
    ctx.fillText(`${x}m`, toPx(x), height - 6);
  }

  ctx.strokeStyle = 'rgba(0, 242, 254, 0.25)';
  ctx.beginPath();
  ctx.moveTo(PAD.left, toPy(0));
  ctx.lineTo(PAD.left + plotW, toPy(0));
  ctx.stroke();

  const progress = (time * 0.22) % 1;
  const headX = progress * MAX_RANGE;

  ctx.strokeStyle = '#00f2fe';
  ctx.lineWidth = 1.75;
  ctx.shadowColor = '#00f2fe';
  ctx.shadowBlur = 8;
  ctx.beginPath();
  for (let x = 0; x <= headX; x += 5) {
    const px = toPx(x);
    const py = toPy(drop(x));
    if (x === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.stroke();
  ctx.shadowBlur = 0;

  ctx.strokeStyle = 'rgba(0, 242, 254, 0.2)';
  ctx.setLineDash([3, 4]);
  ctx.beginPath();
  ctx.moveTo(PAD.left, toPy(drop(MAX_RANGE)));
  ctx.lineTo(PAD.left + plotW, toPy(drop(MAX_RANGE)));
  ctx.stroke();
  ctx.setLineDash([]);

  ctx.fillStyle = '#ff0055';
  ctx.shadowColor = '#ff0055';
  ctx.shadowBlur = 10;
  ctx.beginPath();
  ctx.arc(toPx(MAX_RANGE) - 4, toPy(drop(MAX_RANGE)), 3.5, 0, Math.PI * 2);
  ctx.fill();
  ctx.shadowBlur = 0;

  ctx.fillStyle = '#00f2fe';
  ctx.beginPath();
  ctx.arc(toPx(headX), toPy(drop(headX)), 3, 0, Math.PI * 2);
  ctx.fill();
};

export default function BallisticCurve() {
  const canvasRef = useAnimationCanvas(drawTrajectory);
  return <canvas ref={canvasRef} aria-hidden="true" className="h-full w-full" />;
}
