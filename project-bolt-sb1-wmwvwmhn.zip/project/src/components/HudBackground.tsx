import { useAnimationCanvas, type DrawFn } from '@/hooks/useAnimationCanvas';

const CELL = 56;

const drawGrid: DrawFn = (ctx, width, height, time) => {
  ctx.fillStyle = '#020307';
  ctx.fillRect(0, 0, width, height);

  const offsetY = (time * 14) % CELL;
  const offsetX = (time * 4) % CELL;

  ctx.lineWidth = 1;
  for (let x = -offsetX; x <= width; x += CELL) {
    ctx.strokeStyle = 'rgba(0, 242, 254, 0.06)';
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, height);
    ctx.stroke();
  }
  for (let y = -offsetY; y <= height; y += CELL) {
    ctx.strokeStyle = 'rgba(0, 242, 254, 0.06)';
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(width, y);
    ctx.stroke();
  }

  const bandY = ((time * 0.08) % 1.4 - 0.2) * height;
  const band = ctx.createLinearGradient(0, bandY - 120, 0, bandY + 120);
  band.addColorStop(0, 'rgba(0, 242, 254, 0)');
  band.addColorStop(0.5, 'rgba(0, 242, 254, 0.05)');
  band.addColorStop(1, 'rgba(0, 242, 254, 0)');
  ctx.fillStyle = band;
  ctx.fillRect(0, bandY - 120, width, 240);

  const vignette = ctx.createRadialGradient(width / 2, height / 2, height * 0.2, width / 2, height / 2, Math.max(width, height) * 0.75);
  vignette.addColorStop(0, 'rgba(2, 3, 7, 0)');
  vignette.addColorStop(1, 'rgba(2, 3, 7, 0.9)');
  ctx.fillStyle = vignette;
  ctx.fillRect(0, 0, width, height);
};

export default function HudBackground() {
  const canvasRef = useAnimationCanvas(drawGrid);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 -z-10 h-full w-full"
    />
  );
}
