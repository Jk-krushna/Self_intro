import { useEffect, useState } from 'react';
import BentoCard from '@/components/BentoCard';
import BallisticCurve from '@/components/BallisticCurve';
import RadarSweep from '@/components/RadarSweep';
import { DEFENSE_FOCUS } from '@/data/profile';

function useLiveReadout() {
  const [readout, setReadout] = useState({ bearing: 0, range: 0 });

  useEffect(() => {
    const id = window.setInterval(() => {
      const t = Date.now() / 1000;
      setReadout({
        bearing: Math.floor((t * 68.75) % 360),
        range: 1.2 + 0.8 * Math.abs(Math.sin(t * 0.3)),
      });
    }, 250);
    return () => window.clearInterval(id);
  }, []);

  return readout;
}

export default function DefenseTelemetryCard({ className = '' }: { className?: string }) {
  const { bearing, range } = useLiveReadout();

  return (
    <BentoCard
      code="SYS-01 // BALLISTICS"
      title="Defense Systems & Ballistics Telemetry"
      tone="cyan"
      className={className}
      headerRight={
        <span className="shrink-0 rounded border border-hud-red/40 bg-hud-red/10 px-2 py-0.5 font-mono text-[10px] uppercase tracking-widest text-hud-red">
          Live
        </span>
      }
    >
      <div className="flex items-center gap-4">
        <div className="relative h-32 w-32 shrink-0 md:h-36 md:w-36">
          <RadarSweep />
        </div>
        <dl className="grid flex-1 grid-cols-1 gap-3 font-mono text-xs uppercase tracking-wider">
          <div className="rounded-lg border border-hud-cyan/20 bg-stealth/60 px-3 py-2">
            <dt className="text-[10px] text-slate-500">Bearing</dt>
            <dd className="tabular-nums text-lg text-hud-cyan">{String(bearing).padStart(3, '0')}&deg;</dd>
          </div>
          <div className="rounded-lg border border-hud-cyan/20 bg-stealth/60 px-3 py-2">
            <dt className="text-[10px] text-slate-500">Range</dt>
            <dd className="tabular-nums text-lg text-hud-cyan">{range.toFixed(2)} km</dd>
          </div>
        </dl>
      </div>

      <div className="mt-4 h-28 rounded-lg border border-hud-cyan/15 bg-stealth/50 p-1">
        <BallisticCurve />
      </div>
      <p className="mt-1.5 font-mono text-[10px] uppercase tracking-wider text-slate-500">
        Model: 2D vacuum trajectory, 715 m/s muzzle velocity
      </p>

      <ul className="mt-4 grid gap-2 sm:grid-cols-2">
        {DEFENSE_FOCUS.map((item) => (
          <li key={item} className="flex items-start gap-2 text-sm leading-snug text-slate-300">
            <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-hud-red shadow-[0_0_6px_#ff0055]" />
            {item}
          </li>
        ))}
      </ul>
    </BentoCard>
  );
}
