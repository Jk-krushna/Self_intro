import { motion } from 'framer-motion';
import { Github, Linkedin, Mail, type LucideIcon } from 'lucide-react';
import BentoCard, { TONE_STYLES } from '@/components/BentoCard';
import { PROFILE } from '@/data/profile';

const TICKS = Array.from({ length: 36 }, (_, i) => i * 10);

function AvatarReticle() {
  return (
    <div className="relative aspect-square w-56 shrink-0 md:w-72">
      <svg viewBox="0 0 200 200" className="absolute inset-0 h-full w-full animate-spin-slow" aria-hidden="true">
        <circle cx="100" cy="100" r="97" fill="none" stroke="#00f2fe" strokeWidth="1" strokeDasharray="28 10 4 10" opacity="0.8" />
        {TICKS.map((deg) => (
          <line
            key={deg}
            x1="100"
            y1="3"
            x2="100"
            y2={deg % 30 === 0 ? 14 : 8}
            stroke="#00f2fe"
            strokeWidth={deg % 30 === 0 ? 1.5 : 0.8}
            opacity="0.7"
            transform={`rotate(${deg} 100 100)`}
          />
        ))}
      </svg>

      <svg viewBox="0 0 200 200" className="absolute inset-[7%] h-[86%] w-[86%] animate-spin-reverse" aria-hidden="true">
        <circle cx="100" cy="100" r="96" fill="none" stroke="#ff0055" strokeWidth="2" strokeDasharray="60 180" strokeLinecap="round" />
        <circle cx="100" cy="100" r="96" fill="none" stroke="#ff0055" strokeWidth="1" strokeDasharray="3 9" opacity="0.6" />
      </svg>

      <div className="absolute inset-[16%] overflow-hidden rounded-full">
        <img
          src={PROFILE.avatarUrl}
          alt="Krushna Jadhav"
          className="h-full w-full rounded-full border-2 border-hud-red object-cover shadow-[0_0_35px_rgba(239,68,68,0.5)]"
        />
        <div className="scanlines pointer-events-none absolute inset-0 rounded-full" />
        <div className="pointer-events-none absolute inset-x-0 top-0 h-1/3 animate-scan-y bg-gradient-to-b from-transparent via-hud-cyan/20 to-hud-cyan/5">
          <div className="absolute inset-x-0 bottom-0 h-px bg-hud-cyan shadow-[0_0_12px_#00f2fe]" />
        </div>
        <div className="pointer-events-none absolute inset-y-0 left-0 w-1/3 animate-sweep-x bg-gradient-to-r from-transparent via-hud-red/15 to-transparent" />
      </div>

      <div className="pointer-events-none absolute left-1/2 top-0 h-full w-px -translate-x-1/2 bg-gradient-to-b from-transparent via-hud-cyan/25 to-transparent" />
      <div className="pointer-events-none absolute left-0 top-1/2 h-px w-full -translate-y-1/2 bg-gradient-to-r from-transparent via-hud-cyan/25 to-transparent" />

      <span className="absolute -right-1 top-6 rounded border border-hud-cyan/40 bg-stealth/80 px-1.5 py-0.5 font-mono text-[9px] uppercase tracking-widest text-hud-cyan">
        TGT-LOCK
      </span>
    </div>
  );
}

const SOCIAL_ICONS: Record<'github' | 'linkedin' | 'mail', LucideIcon> = {
  github: Github,
  linkedin: Linkedin,
  mail: Mail,
};

export default function HeroCard({ className = '' }: { className?: string }) {
  return (
    <BentoCard code="HUB-00 // PRIMARY OPERATOR" tone="red" className={`items-center text-center ${className}`}>
      <div className="flex flex-1 flex-col items-center justify-center gap-7 py-4">
        <AvatarReticle />

        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.6 }}
        >
          <h1 className="text-metallic font-display text-3xl font-black tracking-[0.14em] md:text-5xl">
            {PROFILE.name}
          </h1>
          <p className="mx-auto mt-3 max-w-md font-mono text-[11px] uppercase leading-relaxed tracking-[0.18em] text-hud-cyan/80 md:text-xs">
            {PROFILE.subtitle}
          </p>
        </motion.div>

        <ul className="flex flex-wrap justify-center gap-2">
          {PROFILE.badges.map((badge) => (
            <li
              key={badge.label}
              className={`rounded-full border px-3 py-1 font-mono text-[11px] uppercase tracking-wider ${TONE_STYLES[badge.tone].border} ${TONE_STYLES[badge.tone].bg} ${TONE_STYLES[badge.tone].text}`}
            >
              {badge.label}
            </li>
          ))}
        </ul>

        <div className="flex flex-wrap items-center justify-center gap-3">
          {PROFILE.social.map((item) => {
            const Icon = SOCIAL_ICONS[item.kind];
            return (
              <a
                key={item.label}
                href={item.href}
                aria-label={item.label}
                className="glass-hud group/btn flex items-center gap-2 rounded-lg px-4 py-2.5 font-mono text-xs uppercase tracking-wider text-hud-cyan transition-all duration-300 hover:-translate-y-0.5 hover:border-hud-cyan hover:bg-hud-cyan/15 hover:shadow-glow-cyan"
              >
                <Icon className="h-4 w-4 transition-transform duration-300 group-hover/btn:scale-110" />
                {item.label}
              </a>
            );
          })}
        </div>
      </div>
    </BentoCard>
  );
}
