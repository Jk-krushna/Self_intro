import { AnimatePresence, LayoutGroup, motion } from 'framer-motion';
import { useState } from 'react';
import BentoCard from '@/components/BentoCard';
import ParticleBurst from '@/components/ParticleBurst';
import { ARSENAL, ARSENAL_TABS, type ArsenalCategory } from '@/data/profile';

interface ActiveSkill {
  id: string;
  count: number;
}

export default function ArsenalCard({ className = '' }: { className?: string }) {
  const [category, setCategory] = useState<ArsenalCategory>('hardware');
  const [burst, setBurst] = useState<ActiveSkill | null>(null);

  const skills = ARSENAL.filter((skill) => skill.category === category);

  const handleSkillClick = (id: string) => {
    setBurst((prev) => ({ id, count: (prev?.id === id ? prev.count : 0) + 1 }));
  };

  return (
    <BentoCard code="ARS-05 // TACTICAL ARSENAL" title="Technical & Tactical Arsenal" tone="cyan" className={className}>
      <LayoutGroup id="arsenal-tabs">
        <div role="tablist" className="flex flex-wrap gap-1 rounded-lg border border-hud-cyan/15 bg-stealth/60 p-1">
          {ARSENAL_TABS.map((tab) => {
            const active = tab.id === category;
            return (
              <button
                key={tab.id}
                role="tab"
                aria-selected={active}
                type="button"
                onClick={() => setCategory(tab.id)}
                className={`relative flex-1 rounded-md px-3 py-2 font-mono text-[11px] uppercase tracking-wider transition-colors duration-300 ${
                  active ? 'text-stealth' : 'text-slate-400 hover:text-hud-cyan'
                }`}
              >
                {active && (
                  <motion.span
                    layoutId="arsenal-tab-pill"
                    className="absolute inset-0 rounded-md bg-hud-cyan shadow-glow-cyan"
                    transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                  />
                )}
                <span className="relative z-10">{tab.label}</span>
              </button>
            );
          })}
        </div>

        <motion.div layout className="mt-4 flex flex-wrap gap-2.5">
          <AnimatePresence mode="popLayout">
            {skills.map((skill) => {
              const isActive = burst?.id === skill.id;
              return (
                <motion.button
                  key={skill.id}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  whileHover={{ y: -2 }}
                  whileTap={{ scale: 0.96 }}
                  type="button"
                  onClick={() => handleSkillClick(skill.id)}
                  className={`relative rounded-full border px-4 py-2 font-mono text-xs uppercase tracking-wider transition-colors duration-300 ${
                    isActive
                      ? 'border-hud-cyan bg-hud-cyan/15 text-white shadow-glow-cyan laser-border'
                      : 'border-hud-cyan/30 bg-stealth/70 text-slate-200 hover:border-hud-cyan/70 hover:text-hud-cyan'
                  }`}
                >
                  {skill.name}
                  {isActive && burst && <ParticleBurst key={burst.count} />}
                </motion.button>
              );
            })}
          </AnimatePresence>
        </motion.div>
      </LayoutGroup>
    </BentoCard>
  );
}
