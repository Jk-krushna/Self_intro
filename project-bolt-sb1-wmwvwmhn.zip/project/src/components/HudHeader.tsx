import { Crosshair } from 'lucide-react';
import { useEffect, useState } from 'react';

function formatUtc(date: Date) {
  return date.toLocaleTimeString('en-GB', { timeZone: 'UTC', hour12: false });
}

export default function HudHeader() {
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(id);
  }, []);

  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-hud-cyan/15 bg-stealth/70 backdrop-blur-xl">
      <div className="mx-auto flex h-14 max-w-7xl items-center justify-between px-4 md:px-8">
        <div className="flex items-center gap-3">
          <span className="flex h-8 w-8 items-center justify-center rounded-md border border-hud-cyan/40 bg-hud-cyan/10 text-hud-cyan shadow-glow-cyan">
            <Crosshair className="h-4 w-4" />
          </span>
          <div className="leading-none">
            <p className="font-display text-xs font-bold tracking-[0.25em] text-white">KJ-OPS</p>
            <p className="mt-1 font-mono text-[10px] uppercase tracking-[0.2em] text-hud-cyan/60">Portfolio Console</p>
          </div>
        </div>

        <div className="flex items-center gap-4 font-mono text-[11px] uppercase tracking-[0.15em]">
          <span className="hidden text-slate-400 sm:inline">
            UTC <span className="tabular-nums text-hud-cyan">{formatUtc(now)}</span>
          </span>
          <span className="flex items-center gap-2 rounded-full border border-hud-green/40 bg-hud-green/10 px-3 py-1 text-hud-green">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-hud-green shadow-[0_0_8px_#00ff87]" />
            Systems Nominal
          </span>
        </div>
      </div>
    </header>
  );
}
