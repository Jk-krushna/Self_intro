import { useAnimationCanvas, type DrawFn } from '@/hooks/useAnimationCanvas';

const BLIPS = [
  { angle: 0.7, radius: 0.6 },
  { angle: 2.4, radius: 0.35 },
  { angle: 4.1, radius: 0.8 },
  { angle: 5.3, radius: 0.5 },
];

const TAU = Math.PI * 2;

const drawRadar: DrawFn = (ctx, width, height, time) => {
  const cx = width / 2;
  const cy = height / 2;
  const radius = Math.min(width, height) / 2 - 6;

  const glow = ctx.createRadialGradient(cx, cy, 0, cx, cy, radius);
  glow.addColorStop(0, 'rgba(0, 242, 254, 0.12)');
  glow.addColorStop(1, 'rgba(0, 242, 254, 0)');
  ctx.fillStyle = glow;
  ctx.beginPath();
  ctx.arc(cx, cy, radius, 0, TAU);
  ctx.fill();

  ctx.strokeStyle = 'rgba(0, 242, 254, 0.28)';
  ctx.lineWidth = 1;
  for (let i = 1; i <= 4; i++) {
    ctx.beginPath();
    ctx.arc(cx, cy, (radius * i) / 4, 0, TAU);
    ctx.stroke();
  }
  ctx.beginPath();
  ctx.moveTo(cx - radius, cy);
  ctx.lineTo(cx + radius, cy);
  ctx.moveTo(cx, cy - radius);
  ctx.lineTo(cx, cy + radius);
  ctx.stroke();

  const sweep = (time * 1.2) % TAU;
  const trail = 28;
  for (let i = 0; i < trail; i++) {
    const a1 = sweep - i * 0.05;
    const a0 = a1 - 0.05;
    ctx.fillStyle = `rgba(0, 242, 254, ${0.32 * (1 - i / trail)})`;
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.arc(cx, cy, radius, a0, a1);
    ctx.closePath();
    ctx.fill();
  }

  ctx.strokeStyle = '#00f2fe';
  ctx.shadowColor = '#00f2fe';
  ctx.shadowBlur = 8;
  ctx.beginPath();
  ctx.moveTo(cx, cy);
  ctx.lineTo(cx + Math.cos(sweep) * radius, cy + Math.sin(sweep) * radius);
  ctx.stroke();
  ctx.shadowBlur = 0;

  for (const blip of BLIPS) {
    const delta = (sweep - blip.angle + TAU * 2) % TAU;
    const alpha = Math.max(0, 1 - delta / 2.2);
    if (alpha <= 0) continue;
    const x = cx + Math.cos(blip.angle) * radius * blip.radius;
    const y = cy + Math.sin(blip.angle) * radius * blip.radius;
    ctx.fillStyle = `rgba(255, 0, 85, ${alpha})`;
    ctx.beginPath();
    ctx.arc(x, y, 3, 0, TAU);
    ctx.fill();
  }
};

export default function RadarSweep() {
  const canvasRef = useAnimationCanvas(drawRadar);
  return <canvas ref={canvasRef} aria-hidden="true" className="h-full w-full" />;
}
