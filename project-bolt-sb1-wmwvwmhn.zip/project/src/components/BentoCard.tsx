import { motion } from 'framer-motion';
import type { ReactNode } from 'react';

export type Tone = 'cyan' | 'red' | 'green';

export const TONE_STYLES: Record<Tone, { text: string; border: string; bg: string; dot: string }> = {
  cyan: {
    text: 'text-hud-cyan',
    border: 'border-hud-cyan/40',
    bg: 'bg-hud-cyan/10',
    dot: 'bg-hud-cyan shadow-[0_0_10px_#00f2fe]',
  },
  red: {
    text: 'text-hud-red',
    border: 'border-hud-red/40',
    bg: 'bg-hud-red/10',
    dot: 'bg-hud-red shadow-[0_0_10px_#ff0055]',
  },
  green: {
    text: 'text-hud-green',
    border: 'border-hud-green/40',
    bg: 'bg-hud-green/10',
    dot: 'bg-hud-green shadow-[0_0_10px_#00ff87]',
  },
};

interface BentoCardProps {
  code: string;
  title?: string;
  tone?: Tone;
  className?: string;
  headerRight?: ReactNode;
  children: ReactNode;
}

export default function BentoCard({ code, title, tone = 'cyan', className = '', headerRight, children }: BentoCardProps) {
  return (
    <motion.section
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
      className={`group glass-panel hud-corners relative flex flex-col overflow-hidden rounded-2xl p-5 transition-[box-shadow,border-color] duration-500 hover:border-hud-cyan/50 hover:shadow-glow-cyan md:p-6 ${className}`}
    >
      <header className="relative z-10 flex items-center justify-between gap-3">
        <div className="flex min-w-0 items-center gap-2">
          <span className={`h-1.5 w-1.5 shrink-0 animate-pulse rounded-full ${TONE_STYLES[tone].dot}`} />
          <p className="truncate font-mono text-[11px] uppercase tracking-[0.2em] text-hud-cyan/70">{code}</p>
        </div>
        {headerRight}
      </header>
      {title && (
        <h2 className="relative z-10 mt-3 font-display text-base font-bold uppercase leading-tight tracking-wide text-white md:text-lg">
          {title}
        </h2>
      )}
      <div className="relative z-10 mt-4 flex flex-1 flex-col">{children}</div>
    </motion.section>
  );
}
