import { motion } from 'framer-motion';

const PARTICLES = Array.from({ length: 10 }, (_, i) => {
  const angle = (Math.PI * 2 * i) / 10 + (i % 3) * 0.2;
  const distance = 28 + (i % 4) * 9;
  return { x: Math.cos(angle) * distance, y: Math.sin(angle) * distance, color: i % 2 ? '#00f2fe' : '#00ff87' };
});

export default function ParticleBurst() {
  return (
    <span className="pointer-events-none absolute left-1/2 top-1/2" aria-hidden="true">
      {PARTICLES.map((particle, i) => (
        <motion.span
          key={i}
          className="absolute h-1 w-1 rounded-full"
          style={{ backgroundColor: particle.color, boxShadow: `0 0 6px ${particle.color}` }}
          initial={{ x: 0, y: 0, opacity: 1, scale: 1 }}
          animate={{ x: particle.x, y: particle.y, opacity: 0, scale: 0.2 }}
          transition={{ duration: 0.6, ease: 'easeOut' }}
        />
      ))}
    </span>
  );
}
