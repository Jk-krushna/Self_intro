import BentoCard from '@/components/BentoCard';
import { ACADEMIC_GROUPS } from '@/data/profile';

export default function EngineeringCard({ className = '' }: { className?: string }) {
  return (
    <BentoCard code="ACAD-02 // CORE STACK" title="Engineering & Academic Core" tone="green" className={className}>
      <div className="rounded-lg border border-hud-green/20 bg-hud-green/5 px-3 py-2.5">
        <p className="font-mono text-[10px] uppercase tracking-widest text-hud-green/80">B.Tech · Electronics & Computer Engineering</p>
        <p className="mt-1 text-sm text-slate-300">DBATU / SSVPS BS Deore College of Engineering</p>
      </div>

      <div className="mt-4 flex flex-col gap-4">
        {ACADEMIC_GROUPS.map((group) => (
          <div key={group.title}>
            <p className="mb-2 font-mono text-[10px] uppercase tracking-[0.18em] text-slate-500">{group.title}</p>
            <div className="flex flex-wrap gap-2">
              {group.items.map((item) => (
                <span
                  key={item}
                  className="trace-badge cursor-default rounded-md border border-hud-green/25 bg-stealth/70 px-2.5 py-1 font-mono text-xs text-slate-200 transition-colors duration-300 hover:border-hud-green/60 hover:text-hud-green"
                >
                  {item}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </BentoCard>
  );
}
