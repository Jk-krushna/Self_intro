import { motion, AnimatePresence } from 'framer-motion';
import { useState } from 'react';
import BentoCard from '@/components/BentoCard';
import ChipDiagram from '@/components/ChipDiagram';
import { TARGET_ORGS } from '@/data/profile';

const METRIC_LEVELS = [88, 72, 94];

export default function TargetRndCard({ className = '' }: { className?: string }) {
  const [activeId, setActiveId] = useState<string | null>(null);

  return (
    <BentoCard
      code="R&D-04 // TARGET TRAJECTORY"
      title="Target R&D & Career Trajectory"
      tone="green"
      className={className}
    >
      <div className="grid gap-4 md:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)]">
        <div className="relative h-44 rounded-lg border border-hud-cyan/15 bg-stealth/60 p-2">
          <ChipDiagram activeId={activeId} />
        </div>

        <div className="flex flex-col gap-2.5">
          {TARGET_ORGS.map((org) => {
            const active = activeId === org.id;
            return (
              <div
                key={org.id}
                tabIndex={0}
                onMouseEnter={() => setActiveId(org.id)}
                onMouseLeave={() => setActiveId(null)}
                onFocus={() => setActiveId(org.id)}
                onBlur={() => setActiveId(null)}
                className={`rounded-lg border px-3.5 py-3 text-left outline-none transition-all duration-300 focus-visible:border-hud-green/70 ${
                  active
                    ? 'border-hud-green/60 bg-hud-green/10 shadow-glow-green'
                    : 'border-white/10 bg-stealth/50 hover:border-hud-green/30'
                }`}
              >
                <p className="font-display text-sm font-bold uppercase tracking-wider text-white">{org.name}</p>
                <p className="mt-0.5 font-mono text-[11px] uppercase tracking-wider text-hud-green/80">{org.focus}</p>

                <AnimatePresence>
                  {active && (
                    <motion.ul
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      transition={{ duration: 0.35 }}
                      className="mt-3 space-y-2 overflow-hidden"
                    >
                      {org.metrics.map((metric, i) => (
                        <li key={metric}>
                          <div className="flex justify-between font-mono text-[10px] uppercase tracking-wider text-slate-400">
                            <span>{metric}</span>
                            <span className="text-hud-green">SIM</span>
                          </div>
                          <div className="mt-1 h-1 overflow-hidden rounded-full bg-white/10">
                            <motion.div
                              className="h-full rounded-full bg-hud-green shadow-[0_0_8px_#00ff87]"
                              initial={{ width: 0 }}
                              animate={{ width: `${METRIC_LEVELS[i]}%` }}
                              transition={{ duration: 0.8, delay: 0.1 * i, ease: 'easeOut' }}
                            />
                          </div>
                        </li>
                      ))}
                    </motion.ul>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
          <p className="font-mono text-[10px] uppercase tracking-wider text-slate-500">
            Hover a target to load diagnostic overlay
          </p>
        </div>
      </div>
    </BentoCard>
  );
}
