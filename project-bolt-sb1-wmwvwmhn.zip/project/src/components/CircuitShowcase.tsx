import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion';
import { useState, type MouseEvent } from 'react';
import BentoCard from '@/components/BentoCard';
import CircuitCanvas from '@/components/CircuitCanvas';

export default function CircuitShowcase({ className = '' }: { className?: string }) {
  const [hovered, setHovered] = useState(false);
  const px = useMotionValue(0.5);
  const py = useMotionValue(0.5);
  const smoothX = useSpring(px, { stiffness: 140, damping: 18 });
  const smoothY = useSpring(py, { stiffness: 140, damping: 18 });
  const rotateY = useTransform(smoothX, [0, 1], [-12, 12]);
  const rotateX = useTransform(smoothY, [0, 1], [10, -10]);

  const handleMove = (event: MouseEvent<HTMLDivElement>) => {
    const rect = event.currentTarget.getBoundingClientRect();
    px.set((event.clientX - rect.left) / rect.width);
    py.set((event.clientY - rect.top) / rect.height);
  };

  const reset = () => {
    px.set(0.5);
    py.set(0.5);
    setHovered(false);
  };

  return (
    <BentoCard
      code="3D-03 // HOLOGRAPHIC PCB"
      title="Embedded Hardware Simulation & Signal Processing"
      tone="cyan"
      className={className}
    >
      <div className="relative flex-1" style={{ perspective: 900 }} onMouseMove={handleMove} onMouseEnter={() => setHovered(true)} onMouseLeave={reset}>
        <motion.div
          style={{ rotateX, rotateY, transformStyle: 'preserve-3d' }}
          className="relative h-64 w-full overflow-hidden rounded-xl border border-hud-cyan/25 bg-stealth/80 shadow-[inset_0_0_40px_rgba(0,242,254,0.06)] md:h-72"
        >
          <CircuitCanvas />
          <div className="scanlines pointer-events-none absolute inset-0" />
          <div className="pointer-events-none absolute left-3 top-3 font-mono text-[10px] uppercase tracking-widest text-hud-cyan/70">
            {hovered ? 'Tilt: manual' : 'Tilt: hover to steer'}
          </div>
        </motion.div>
      </div>
    </BentoCard>
  );
}
