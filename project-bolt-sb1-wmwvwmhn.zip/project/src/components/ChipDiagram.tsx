import { motion } from 'framer-motion';

interface ChipDiagramProps {
  activeId: string | null;
}

const NODES = [
  { x: 84, y: 62, delay: 0 },
  { x: 102, y: 74, delay: 0.6 },
  { x: 92, y: 88, delay: 1.2 },
  { x: 136, y: 66, delay: 0.3 },
  { x: 150, y: 84, delay: 0.9 },
  { x: 132, y: 96, delay: 1.5 },
  { x: 118, y: 120, delay: 0.4 },
];

const PINS_X = [70, 84, 98, 112, 126, 140, 154];
const PINS_Y = [40, 52, 64, 76, 88, 100, 112, 124, 136];

export default function ChipDiagram({ activeId }: ChipDiagramProps) {
  const nvidia = activeId === 'nvidia';
  const samsung = activeId === 'samsung';
  const nvColor = '#00ff87';
  const samColor = '#00f2fe';

  return (
    <svg viewBox="0 0 220 180" className="h-full w-full" aria-hidden="true">
      {PINS_X.map((x) => (
        <g key={`pin-${x}`} stroke="rgba(0,242,254,0.5)" strokeWidth="2">
          <line x1={x} y1="22" x2={x} y2="30" />
          <line x1={x} y1="150" x2={x} y2="158" />
        </g>
      ))}
      {PINS_Y.map((y) => (
        <g key={`pinh-${y}`} stroke="rgba(0,242,254,0.5)" strokeWidth="2">
          <line x1="50" y1={y} x2="60" y2={y} />
          <line x1="160" y1={y} x2="170" y2={y} />
        </g>
      ))}

      <rect x="60" y="30" width="100" height="120" rx="6" fill="#05070c" stroke="rgba(0,242,254,0.6)" strokeWidth="1.2" />
      <rect x="60" y="30" width="100" height="120" rx="6" fill="none" stroke="rgba(0,242,254,0.15)" strokeWidth="6" />

      <rect
        x="72"
        y="42"
        width="38"
        height="46"
        rx="3"
        fill={nvidia ? 'rgba(0,255,135,0.18)' : 'rgba(0,255,135,0.05)'}
        stroke={nvColor}
        strokeWidth={nvidia ? 1.6 : 0.8}
        style={{ transition: 'all 0.4s ease' }}
      />
      <text x="91" y="70" fill={nvColor} fontSize="7" textAnchor="middle" fontFamily="JetBrains Mono, monospace">NV-AI</text>

      <rect
        x="112"
        y="42"
        width="38"
        height="46"
        rx="3"
        fill={samsung ? 'rgba(0,242,254,0.18)' : 'rgba(0,242,254,0.05)'}
        stroke={samColor}
        strokeWidth={samsung ? 1.6 : 0.8}
        style={{ transition: 'all 0.4s ease' }}
      />
      <text x="131" y="70" fill={samColor} fontSize="7" textAnchor="middle" fontFamily="JetBrains Mono, monospace">VLSI</text>

      <rect x="72" y="98" width="78" height="30" rx="3" fill="rgba(255,0,85,0.06)" stroke="rgba(255,0,85,0.6)" strokeWidth="0.8" />
      <text x="111" y="116" fill="#ff0055" fontSize="7" textAnchor="middle" fontFamily="JetBrains Mono, monospace">BUS / CLK</text>

      {NODES.map((node, i) => {
        const color = i < 3 ? nvColor : i < 6 ? samColor : '#ff0055';
        return (
          <motion.circle
            key={`${node.x}-${node.y}`}
            cx={node.x}
            cy={node.y}
            r="2"
            fill={color}
            animate={{ opacity: [0.2, 1, 0.2], r: [1.5, 2.6, 1.5] }}
            transition={{ duration: 2.4, repeat: Infinity, delay: node.delay, ease: 'easeInOut' }}
          />
        );
      })}
    </svg>
  );
}
