import BentoCard from '@/components/BentoCard';
import CursorReticle from '@/components/CursorReticle';
import DefenseTelemetryCard from '@/components/DefenseTelemetryCard';
import EngineeringCard from '@/components/EngineeringCard';
import HeroCard from '@/components/HeroCard';
import HudBackground from '@/components/HudBackground';
import HudHeader from '@/components/HudHeader';
import ArsenalCard from '@/components/ArsenalCard';
import CircuitShowcase from '@/components/CircuitShowcase';
import LabCard from '@/components/LabCard';
import TargetRndCard from '@/components/TargetRndCard';

function App() {
  return (
    <div className="relative min-h-screen overflow-x-hidden font-sans text-slate-300">
      <HudBackground />
      <CursorReticle />
      <HudHeader />

      <main className="relative z-10 mx-auto max-w-7xl px-4 pb-20 pt-24 md:px-8 md:pt-28">
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-12 lg:gap-5">
          <HeroCard className="order-first md:col-span-2 lg:order-none lg:col-span-4 lg:row-span-2" />
          <DefenseTelemetryCard className="md:col-span-1 lg:col-span-4 lg:row-span-2" />
          <EngineeringCard className="md:col-span-1 lg:col-span-4" />
          <CircuitShowcase className="md:col-span-2 lg:col-span-4" />
          <TargetRndCard className="md:col-span-2 lg:col-span-4" />
          <ArsenalCard className="md:col-span-1 lg:col-span-4" />
          <LabCard className="md:col-span-1 lg:col-span-4" />
        </div>

        <footer className="mt-10 flex flex-col items-center justify-between gap-2 border-t border-hud-cyan/10 pt-5 font-mono text-[10px] uppercase tracking-[0.2em] text-slate-500 sm:flex-row">
          <span>Krushna Jadhav // Embedded Systems & Defense Tech</span>
          <span className="text-hud-green/80">All systems operational</span>
        </footer>
      </main>
    </div>
  );
}

export default App;
